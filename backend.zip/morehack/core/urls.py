from django.contrib import admin
from django.urls import include, path
from .views import PointView

urlpatterns = [

    path('points/', PointView.as_view(), name='point-view'),


]
