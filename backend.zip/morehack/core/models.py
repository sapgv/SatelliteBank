from django.db import models

# Create your models here.
class Point(models.Model):
    name = models.CharField(max_length=128, blank=True)
    bankomat = models.BooleanField(default=False)
    bankomat_allday = models.BooleanField(default=False)
    bankomat_wheelchair = models.BooleanField(default=False)
    bankomat_blind = models.BooleanField(default=False)
    bankomat_nfc = models.BooleanField(default=False)
    bankomat_qr = models.BooleanField(default=False)
    bankomat_eur = models.BooleanField(default=False)
    bankomat_usd = models.BooleanField(default=False)
    bankomat_rub = models.BooleanField(default=True)
    bankomat_in = models.BooleanField(default=True)
    address = models.CharField(max_length=128, blank=True)
    corporate = models.BooleanField(default=False)
    openHoursCorporate = models.JSONField(blank=True, null=True)
    openIndividual = models.JSONField(blank=True, null=True)
    suo = models.BooleanField(default=False)
    ramp = models.BooleanField(default=False)
    latitude = models.FloatField(null=True)
    longitude = models.FloatField(null=True)
    load = models.JSONField(blank=True, null=True)
    
    
    
"""
 'salePointName': 'ДО ЦИК «Пушечный» Филиала № 7701 Банка ВТБ (ПАО)',
 'address': '107031, г. Москва, ул. Кузнецкий мост, д. 16/5, стр. 1',
 'status': 'открытая',
 'openHours': [{'days': 'Не обслуживает ЮЛ', 'hours': None}],
 'rko': 'нет РКО',
 'openHoursIndividual': [{'days': 'пн', 'hours': '09:00-18:00'},
  {'days': 'вт', 'hours': '09:00-18:00'},
  {'days': 'ср', 'hours': '09:00-18:00'},
  {'days': 'чт', 'hours': '09:00-18:00'},
  {'days': 'пт', 'hours': '09:00-18:00'},
  {'days': 'сб', 'hours': 'выходной'},
  {'days': 'вс', 'hours': 'выходной'}],
 'officeType': 'Да',
 'salePointFormat': 'Розничный (РБ)',
 'suoAvailability': 'N',
 'hasRamp': 'Y',
 'latitude': 55.761597,
 'longitude': 37.622082,
 'metroStation': 'Москва, Таганско-Краснопресненская линия, метро Кузнецкий Мост',
 'distance': 841,
 'kep': False,
 'myBranch': False}
"""