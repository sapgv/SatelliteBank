from django.shortcuts import render
from .models import Point
# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import PointSerializer
import math
from geopy.distance import distance

def dist(origin, destination):
    lat1, lon1 = origin
    lat2, lon2 = destination
    radius = 6371 # km

    dlat = math.radians(lat2-lat1)
    dlon = math.radians(lon2-lon1)
    a = math.sin(dlat/2) * math.sin(dlat/2) + math.cos(math.radians(lat1)) \
        * math.cos(math.radians(lat2)) * math.sin(dlon/2) * math.sin(dlon/2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    d = radius * c

    return d

class PointView(APIView):
    def post(self, request):
        lat = request.data.get('latitude', 55.75)  
        lng = request.data.get('longitude', 37.61) 
        filtered_points = []
        for point in Point.objects.all():
            point_distance = distance((lat, lng), (point.latitude, point.longitude)).km
            if point_distance <= 1:
                filtered_points.append(point)

        #filtered_points = Point.objects.all()        
        serializer = PointSerializer(filtered_points, many=True)
        return Response(serializer.data)
