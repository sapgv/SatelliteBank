import re
import sys
import django
import os
import json
PATH=os.getcwd()
sys.path.append(f"{PATH}")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "morehack.settings")
django.setup()
import random
# your imports, e.g. Django models

from core.models import Point
Point.objects.all().delete()


with open(f"{PATH}/offices.json") as inp:
        rows=[]
        j = json.loads(inp.read())
        for r in j:
            p={}
            p['bankomat']=False
            p['address']=r['address']
            p['latitude']=r['latitude']
            p['longitude']=r['longitude']
            p['corporate']=r['rko'] == 'Есть РКО'
            p['openHoursCorporate']={"hours":r['openHours']}
            p['openIndividual']={"hours":r['openHoursIndividual']}
            p['suo']=r['suoAvailability']=='Y'
            p['ramp']=r['hasRamp']=='Y'

            rows.append(Point(**p))
        Point.objects.bulk_create(rows)

with open(f"{PATH}/atms.json") as inp:
        rows=[]
        j = json.loads(inp.read())
        for r in j['atms']:
            p={}
            p['bankomat']=True
            p['address']=r['address']
            p['latitude']=r['latitude']
            p['longitude']=r['longitude']
            p['bankomat_wheelchair']=r['services']['wheelchair']['serviceActivity']=='AVAILABLE'
            p['bankomat_nfc']=r['services']['nfcForBankCards']['serviceActivity']=='AVAILABLE'
            p['bankomat_qr']=r['services']['qrRead']['serviceActivity']=='AVAILABLE'
            p['bankomat_usd']=r['services']['supportsUsd']['serviceActivity']=='AVAILABLE'
            p['bankomat_eur']=r['services']['supportsEur']['serviceActivity']=='AVAILABLE'
            p['bankomat_rub']=r['services']['supportsRub']['serviceActivity']=='AVAILABLE'
            p['bankomat_in']=r['services']['supportsChargeRub']['serviceActivity']=='AVAILABLE'
            p['bankomat_allday']=r['allDay']

            rows.append(Point(**p))
        Point.objects.bulk_create(rows)

for p in Point.objects.all():
   load ={}
   for d in 'пн,вт,ср,чт,пт,сб,вс'.split(','):
       load[d]=random.sample(range(10, 91), 24)
   p.load=load
   p.save()